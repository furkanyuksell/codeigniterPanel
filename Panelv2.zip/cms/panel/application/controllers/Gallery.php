<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gallery extends CI_Controller {

    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();

        $this->viewFolder = "galleryPage_v";
        
        $this->load->model("categori_model");
        $this->load->model("games_model");
        $this->load->model("gallery_model");

        if(!get_active_user()){
            redirect(base_url("login"));
        }

    }

    public function index()
	{
	    $viewData = new stdClass();
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";

		$this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
	}

    public function routing($id, $gameUrl)
    {
        $viewData = new stdClass();
        $categori = $this->categori_model->get_all(
            array(), "rank ASC"
        );
        $game = $this->games_model->get(
            array(
                "id"     => $id
            )
        );
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->categori = $categori;
        $viewData->game = $game;

		$this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function imageUpload($categori, $gameUrl, $gameId)
    {
        $file_name = convertToSEO(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)).".".pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $config["allowed_types"] = "*";
        $config["upload_path"] = "uploads/games_v/$gameUrl";
        $config["file_name"] = $file_name;
        $this->load->library("upload",$config);

        $ext = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);

        $upload = $this->upload->do_upload("file");
        if ($upload) {
            $uploaded_file = $this->upload->data("file_name");
            if ($ext != "unitypackage") {
                $this->gallery_model->add(
                    array(
                        "imageUrl"      => $uploaded_file,
                        "imageName"     => pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME),
                        "imageCategori" => $categori,
                        "gameId"        => $gameId,
                        "gameUrl"       => $gameUrl
                    )
                );   
            }else{
                $this->gallery_model->update(
                    array(
                        "imageName" => pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME),
                        "gameId"    => $gameId  
                    ),
                    array(
                        "imagePackageUrl" => $uploaded_file
                    )
                );
            }
        }
        else{
            echo "islem basarisiz";
        }
    }
}
