<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Videos extends CI_Controller {

    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();

        $this->viewFolder = "video_v";
        $this->load->model("Video_panel_model");
        $this->load->model("video_model");
        $this->load->model("photo_model");
        $this->load->model("zip_model");
        
        if(!get_active_user()){
            redirect(base_url("login"));
        }

    }

    public function index()
	{
	    $viewData = new stdClass();

        $items = $this->Video_panel_model->get_all(
            array(), "id DESC"
        );

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->items = $items;

		$this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
	}

    public function new_form(){
        $viewData = new stdClass();

        /** View'e gönderilecek Değişkenlerin Set Edilmesi.. */
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "add";

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);

    }

    public function save(){

        $this->load->library("form_validation");
        $this->form_validation->set_rules("gameName", "Oyun Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required"  => "<b>{field}</b> alanı doldurulmalıdır"
            )
        );
        $validate = $this->form_validation->run();

        if($validate){
            $path = "uploads/$this->viewFolder/".convertToSEO($this->input->post("gameName"));
            $create_folder = mkdir($path, 0755);
            if ($create_folder) {
                $insert = $this->Video_panel_model->add(
                    array(
                        "v_gameUrl"   => convertToSEO($this->input->post("gameName")),
                        "v_gameName"    => $this->input->post("gameName")
                    )
                );                
            }
            
            if($insert){
                $alert = array(
                    "title" => "Başarılı",
                    "text" => "Kategori doğru şekilde oluşturuldu",
                    "type" => "success"
                );
            } else {
                $alert = array(
                    "title" => "Hata",
                    "text" => "Kategori oluşturma başarısız",
                    "type" => "error"
                );
            }

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("videos"));
        } else {

            $viewData = new stdClass();
            $viewData->viewFolder = $this->viewFolder;
            $viewData->subViewFolder = "add";
            $viewData->form_error = true;

            $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
        }
    }

    public function routing($id)
    {
        $viewData = new stdClass();
        
        $videoGame = $this->Video_panel_model->get(
            array(
                "id"     => $id
            )
        );

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "addFile";
        $viewData->videoGame = $videoGame;

		$this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function videoUpload($id, $gameUrl)
    {
        $file_name = convertToSEO(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)).".".pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $config["allowed_types"] = "*";
        $config["upload_path"] = "uploads/marketing_v/$gameUrl";
        $config["file_name"] = $file_name;
        $this->load->library("upload",$config);

        $upload = $this->upload->do_upload("file");
        if ($upload) {
            $uploaded_file = $this->upload->data("file_name");
            $this->video_model->add(
                array(
                    "videoUrl"      => $uploaded_file,
                    "videoName"     => pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME),
                    "videoGameId"   => $id
                )
            );
        }
        else{
            echo "islem basarisiz";
        }
    }
    
    public function photoUpload($id, $gameUrl)
    {
        $file_name = convertToSEO(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)).".".pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $config["allowed_types"] = "*";
        $config["upload_path"] = "uploads/marketing_v/$gameUrl";
        $config["file_name"] = $file_name;
        $this->load->library("upload",$config);

        $upload = $this->upload->do_upload("file");
        if ($upload) {
            $uploaded_file = $this->upload->data("file_name");
            $this->photo_model->add(
                array(
                    "photoUrl"      => $uploaded_file,
                    "photoName"     => pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME),
                    "videoGameId"   => $id
                )
            );
        }
        else{
            echo "islem basarisiz";
        }
    }

    public function zipUpload($id, $gameUrl)
    {
        $file_name = convertToSEO(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)).".".pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $config["allowed_types"] = "*";
        $config["upload_path"] = "uploads/marketing_v/$gameUrl";
        $config["file_name"] = $file_name;
        $this->load->library("upload",$config);

        $upload = $this->upload->do_upload("file");
        if ($upload) {
            $uploaded_file = $this->upload->data("file_name");
            $this->zip_model->add(
                array(
                    "zipUrl"      => $uploaded_file,
                    "zipName"     => pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME),
                    "videoGameId"   => $id
                )
            );
        }
        else{
            echo "islem basarisiz";
        }
    }

    public function viewGameMarketings($id)
    {
        $viewData = new stdClass();
        
        $marketingGame = $this->Video_panel_model->get(
            array(
                "id"     => $id
            )
        );

        $marketingVideos = $this->video_model->get_all(
            array(
                "videoGameId"     => $id
            )
        );

        $marketingPhotos = $this->photo_model->get_all(
            array(
                "videoGameId"     => $id
            )
        );

        $marketingZips = $this->zip_model->get_all(
            array(
                "videoGameId"     => $id
            )
        );

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "video";
        $viewData->marketingGame = $marketingGame;
        $viewData->marketingVideos = $marketingVideos;
        $viewData->marketingPhotos = $marketingPhotos;
        $viewData->marketingZips = $marketingZips;

		$this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function viewDeletePage($id, $page)
    {
        $viewData = new stdClass();
        
        $marketingGame = $this->Video_panel_model->get(
            array(
                "id"     => $id
            )
        );

        $marketingVideos = $this->video_model->get_all(
            array(
                "videoGameId"     => $id
            )
        );

        $marketingPhotos = $this->photo_model->get_all(
            array(
                "videoGameId"     => $id
            )
        );

        $marketingZips = $this->zip_model->get_all(
            array(
                "videoGameId"     => $id
            )
        );

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = $page;
        $viewData->marketingGame = $marketingGame;
        $viewData->marketingVideos = $marketingVideos;
        $viewData->marketingPhotos = $marketingPhotos;
        $viewData->marketingZips = $marketingZips;

		$this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function deleteForm($id){
        $viewData = new stdClass();
        $images = $this->gallery_model->get_all(
            array(
                "gameId" => $id
            )
        );
        $game = $this->games_model->get(
            array(
                "id" => $id
            )
        );
        
        /** View'e gönderilecek Değişkenlerin Set Edilmesi.. */
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "update";
        $viewData->images = $images;
        $viewData->game = $game;
        

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);

    }

    public function delete($gameId, $gameUrl, $model, $id, $photoUrl, $redirect)
    {
        $delete = $this->$model->delete(
            array(
                "id" => $id
            )
        );
        if ($delete) {
            $filedelete = unlink("uploads/marketing_v/$gameUrl/$photoUrl");
        }
        
        if ($delete && $filedelete) {
            $alert = array(
                "title" => "Başarılı",
                "text" => "$photoUrl silindi",
                "type" => "success"
            );
        }else{
            $alert = array(
                "title" => "Hata",
                "text" => "$photoUrl silme başarısız",
                "type" => "error"
            );
        }
        
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url("videos/viewDeletePage/$gameId/$redirect"));
    }

    public function deleteImage($id)
    {
        $getImage = $this->gallery_model->get(
            array(
                "id" => $id
            )
        );
        $delete = $this->gallery_model->delete(
            array(
                "id" => $id
            )
        );
        
        if ($delete) {
            unlink("uploads/{$this->viewFolder}/$getImage->gameUrl/$getImage->imageUrl");
            unlink("uploads/{$this->viewFolder}/$getImage->gameUrl/$getImage->imagePackageUrl");
            $alert = array(
                "title" => "Başarılı",
                "text" => "Resim silindi",
                "type" => "success"
            );
        }else{
            $alert = array(
                "title" => "Hata",
                "text" => "Kategori silme başarısız",
                "type" => "error"
            );
        }
        
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url("games/deleteForm/$getImage->gameId"));
    }

    public function update($id){

        $this->load->library("form_validation");
        $this->form_validation->set_rules("gameName", "Oyun Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required"  => "<b>{field}</b> alanı doldurulmalıdır"
            )
        );

        $validate = $this->form_validation->run();

        if($validate){
            $getGame = $this->games_model->get(
                array(
                    "id" => $id
                )
            );
            $updateGame = $this->games_model->update(
                array(
                    "id" => $id
                ),

                array(
                    "gameUrl"   => convertToSEO($this->input->post("gameName")),
                    "gameName"  => $this->input->post("gameName")
                )
            );

            $updateGallery = $this->gallery_model->update(
                array(
                    "gameId" => $id
                ),

                array(
                    "gameUrl"   => convertToSEO($this->input->post("gameName"))
                )
            );
            $newGameName = convertToSEO($this->input->post("gameName"));
            if($updateGame && $updateGallery && rename("uploads/{$this->viewFolder}/$getGame->gameUrl", "uploads/{$this->viewFolder}/$newGameName")){
                $alert = array(
                    "title" => "Başarılı",
                    "text" => "Oyun adı güncellendi",
                    "type" => "success"
                );
            } else {
                $alert = array(
                    "title" => "Hata",
                    "text" => "Kategori güncelleme başarısız",
                    "type" => "error"
                );
            }

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("games"));
        } else {

            $viewData = new stdClass();
            $item = $this->games_model->get(
                array(
                    "id" => $id
                )
            );
            $viewData->viewFolder = $this->viewFolder;
            $viewData->subViewFolder = "update";
            $viewData->form_error = true;
            $viewData->item = $item;

            $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
        }
    }


    public function isChangeSubCategori($id){

        $subCategori = $this->input->post("data");
        if($id){
            $this->gallery_model->update(
                array(
                    "id"    => $id
                ),
                array(
                    "imageSubCategori"  => $subCategori
                )
            );
        }else{
            echo "hata";
        }
    }
}
