<?php

class Blankpage extends CI_Controller
{
    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();

        $this->viewFolder = "blankpage_v";

        $this->load->model("categori_model");
        $this->load->model("subcategori_model");
        $this->load->model("gallery_model");

        if(!get_active_user()){
            redirect(base_url("login"));
        }

    }

    public function categoriDetail($url)
    {
        $categori = $this->categori_model->get(
            array(
                "categoriUrl" => $url
            )
        );

        $subcategori = $this->subcategori_model->get_all(
            array(
                "parentCategori" => $categori->categoriName 
            )
        );

        $viewData = new stdClass();

        $items = $this->gallery_model->get_all(
            array(
                "imageCategori" => $categori->categoriName
            )
        );
        
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->items = $items;
        $viewData->subcategori = $subcategori;

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function subCategoriDetail($url)
    {
        $subcategoriChoosen = $this->subcategori_model->get(
            array(
                "subcategoriUrl" => $url
            )
        );

        $subcategori = $this->subcategori_model->get_all(
            array(
                "parentCategori" => $subcategoriChoosen->parentCategori 
            )
        );

        $items = $this->gallery_model->get_all(
            array(
                "imageSubCategori" => $subcategoriChoosen->subcategoriName
            )
        );

        $viewData = new stdClass();

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->items = $items;
        $viewData->subcategori = $subcategori;
        

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function gameDetail($url)
    {
        $viewData = new stdClass();

        $items = $this->gallery_model->get_all(
            array(
                "gameUrl" => $url
            )
        );
        
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->items = $items;
        $viewData->isGame = 1;
        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

}
