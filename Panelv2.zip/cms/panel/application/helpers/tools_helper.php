<?php

function convertToSEO($text){

    $turkce  = array("ç", "Ç", "ğ", "Ğ", "ü", "Ü", "ö", "Ö", "ı", "İ", "ş", "Ş", ".", ",", "!", "'", "\"", " ", "?", "*", "_", "|", "=", "(", ")", "[", "]", "{", "}");
    $convert = array("c", "c", "g", "g", "u", "u", "o", "o", "i", "i", "s", "s", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-");
    
    return strtolower(str_replace($turkce, $convert, $text));
}

function get_active_user(){

    $t = &get_instance();

    $user = $t->session->userdata("user");

    if($user)
        return $user;
    else
        return false;

}

function get_active_userLevel(){

    $t = &get_instance();

    $user = $t->session->userdata("user");

    if($user)
        return $user->userLevel;
    else
        return false;

}

function get_gameName($id){

    $t = &get_instance();

    $t->load->model("games_model");
    
    $gameName = $t->games_model->get(
        array(
            "id" => $id
        )
    );
    return $gameName;

}

function get_settings(){

    $t = &get_instance();

    $t->load->model("settings_model");

    if($t->session->userdata("settings")){
        $settings = $t->session->userdata("settings");
    } else {

        $settings = $t->settings_model->get();

        if(!$settings) {

            $settings = new stdClass();
            $settings->company_name = "Compony Name";
            $settings->logo         = "default";
            
        }

        $t->session->set_userdata("settings", $settings);

    }

    return $settings;

}


function get_categori(){

    $t = &get_instance();

    $t->load->model("categori_model");

    if($t->session->userdata("categori")){
        $categori = $t->session->userdata("categori");
    } else {

        $categori = $t->categori_model->get_all();

        if(!$categori) {

            $categori = new stdClass();
            $categori->categoriUrl  = "#";
            $categori->categoriName = "Non";
            
        }

        $t->session->set_userdata("categori", $categori);

    }

    return $categori;

}

/*function get_games(){

    $t = &get_instance();

    $t->load->model("games_model");

    if($t->session->userdata("games")){
        $games = $t->session->userdata("games");
    } else {

        $games = $t->games_model->get_all(
            array(), "id DESC"
        );

        if(!$games) {

            $games = new stdClass();
            $games->gameUrl  = "#";
            $games->gameName = "Non";
            
        }

        $t->session->set_userdata("games", $games);

    }

    return $games;

}*/
function get_games(){

    $t = &get_instance();

    $t->load->model("games_model");
    $games = $t->games_model->get_all(
        array(), "id DESC"
    );
    return $games;

}

/*
function get_subcategori($categoriName){

    $t = &get_instance();

    $t->load->model("subcategori_model");

    if($t->session->userdata("subcategori")){
        $subcategori = $t->session->userdata("subcategori");
    } else {

        $subcategori = $t->subcategori_model->get_all(
            array(
                "parentCategori" => $categoriName
            )
        );

        if(!$subcategori) {

            $subcategori = new stdClass();
            $subcategori->subcategoriUrl  = "#";
            $subcategori->subcategoriName = "Non";
            $subcategori->parentCategori  = "Non";
            
        }

        $t->session->set_userdata("subcategori", $subcategori);

    }

    return $subcategori;

}
*/

function get_subcategori($categoriName){

    $t = &get_instance();

    $t->load->model("subcategori_model");

    $subcategori = $t->subcategori_model->get_all(
        array(
            "parentCategori" => $categoriName
        )
    );
    
    return $subcategori;

}