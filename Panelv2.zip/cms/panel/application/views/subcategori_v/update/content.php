<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php echo "<b>$item->subcategoriName</b> adlı kategori düzenle" ?>
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">
                <form action="<?php echo base_url("subcategori/update/$item->id"); ?>" method="post">
                    <div class="form-group">
                        <label>Subcategory Name (example: Animal)</label>
                        <input class="form-control" placeholder="Subcategori Name" name="subcategoriName" value="<?php echo $item->subcategoriName ?>">
                        <?php if(isset($form_error)){ ?>
                            <small class="input-form-error"> <?php echo form_error("subcategoriName"); ?></small>
                        <?php } ?>
                    </div>
                    <div class="form-group">
                        <label>Subcategory Icon (example: fa fa-anim)</label>
                        <input class="form-control" placeholder="Subcategori Icon" name="subcategoriIcon" value="<?php echo $item->subcategoriIcon ?>">
                        <?php if(isset($form_error)){ ?>
                            <small class="input-form-error"> <?php echo form_error("subcategoriIcon"); ?></small>
                        <?php } ?>
                    </div>
                    <div class="form-group">
                        <label>Üst Kategorisi</label>
						<select class="form-control" name="parentCategori" data-plugin="select2" data-options="{ placeholder: 'Bir kategori seçiniz', allowClear: true }">
                            <?php foreach ($parentCategori as $pCategori) { ?>
                                <option <?php if($pCategori->categoriName === $item->parentCategori) echo "selected"; ?> value="<?php echo $pCategori->categoriName ?>"><?php echo $pCategori->categoriName ?></option>
                            <?php } ?>
						</select>
					</div>
                    <button type="submit" class="btn btn-primary btn-md btn-outline">Güncelle</button>
                    <a href="<?php echo base_url("subcategori"); ?>" class="btn btn-md btn-danger btn-outline">İptal</a>
                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div><!-- END column -->
</div>