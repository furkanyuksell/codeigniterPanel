<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php echo "<b>$marketingGame->v_gameName</b> adlı oyunu düzenle" ?> 
            <a href="<?php echo base_url("videos"); ?>" class="btn btn-outline btn-primary btn-s"> <i class="fa fa-chevron-left"></i> Oyunlar</a>
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">
                <?php if(empty($marketingVideos) && empty($marketingPhotos) && empty($marketingZips)) { ?>

                <div class="alert alert-info text-center">
                    <p>Burada herhangi bir resim bulunmamaktadır.</a></p>
                </div>

                <?php } else { ?>

                    <div class="promo-footer">
                        <div class="row no-gutter">
                            <div class="col-sm-4 col-xs-4 promo-tab">
                                <a href="<?php echo base_url("videos/viewGameMarketings/$marketingGame->id") ?>">Videolar</a>
                            </div>
                            <div class="col-sm-4 col-xs-4 promo-tab">
                                <a href="search.video.html">Fotoğraflar</a>
                            </div>
                            <div class="col-sm-4 col-xs-4 promo-tab">
                                <a href="search.users.html">Zipler</a>
                            </div>
                        </div>
                    </div>
                    <div class="wrap">
                        <section class="app-content">
                            <!-- search results -->
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <div>
                                        <div class="row">
                                            <?php 
                                            foreach ($marketingVideos as $m_video) {
                                            ?>    
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="m-b-lg">
                                                        <video width="100%" height="300" controls>
                                                            <source src="<?php echo base_url("uploads/marketing_v/$marketingGame->v_gameUrl/$m_video->videoUrl"); ?>" type="video/mp4">
                                                            Your browser does not support HTML video.
                                                        </video>
                                                    </div>
                                                </div><!-- END column -->
                                            <?php } ?>
                                        </div><!-- .row -->
                                    </div>
                                </div>
                            </div>
                        </section><!-- #dash-content -->
                    </div>
                <?php } ?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div><!-- END column -->
</div>