<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php echo "<b>$game->gameName</b> adlı oyunu düzenle" ?> 
            <a href="<?php echo base_url("games"); ?>" class="btn btn-outline btn-primary btn-s"> <i class="fa fa-chevron-left"></i> Oyunlar</a>
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">
                <form action="<?php echo base_url("games/update/$game->id"); ?>" method="post">
                    <div class="form-group">
                        <label>Oyunun Adı</label>
                        <input class="form-control" placeholder="Oyun adı" name="gameName" value="<?php echo $game->gameName ?>">
                        <?php if(isset($form_error)){ ?>
                            <small class="input-form-error"> <?php echo form_error("gameName"); ?></small>
                        <?php } ?>
                    </div>
                    <button type="submit" class="btn btn-primary btn-md btn-outline">Güncelle</button>
                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div><!-- END column -->
    <div class="col-md-4">
        <div class="widget">
            <div class="widget-body">
                <?php if(empty($images)) { ?>

                <div class="alert alert-info text-center">
                    <p>Burada herhangi bir resim bulunmamaktadır.</a></p>
                </div>

                <?php } else { ?>

                <table class="table table-bordered table-striped table-hover pictures_list">
                    <thead>
                    <th class="text-center">#id</th>
                    <th class="text-center">Görsel</th>
                    <th class="text-center">UnityPackage</th>
                    <th class="text-center">İşlem</th>
                    </thead>
                    <tbody>

                    <?php foreach($images as $image){ ?>

                        <tr>
                            <td class="text-center" style=""><p class="center-button-now">#<?php echo $image->id; ?></p></td>
                            <td class="text-center">
                                <img style="width: 200px; height: 200px;" class="img-responsive" src="<?php echo base_url("uploads/games_v/$image->gameUrl/$image->imageUrl"); ?>" alt="">
                            </td>
                            <td class="text-center" style=""><p class="center-button-now"><?php echo $image->imagePackageUrl; ?></p></td>
                            <td class="text-center">
                                <button 
                                    data-url="<?php echo base_url("games/deleteImage/$image->id") ?>" 
                                    class="btn btn-sm btn-danger btn-outline remove-btn center-button-now">
                                    <i class="fa fa-trash"></i> 
                                    Sil
                                </button>
                            </td>
                        </tr>

                    <?php } ?>

                    </tbody>

                </table>
                <?php } ?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div><!-- END column -->
</div>