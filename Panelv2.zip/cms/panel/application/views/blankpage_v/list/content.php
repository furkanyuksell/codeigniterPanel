<section class="app-content">
<?php if(empty($items)) { ?>

<div class="alert alert-info text-center">
    <p>Burada herhangi bir görsel bulunmamaktadır.</a></p>
</div>

<?php 
} 
else{?>

<?php if(isset($isGame)){ ?>
<div class="col-md-12">
    <div class="widget">
        <header class="widget-header">
            <h4 class="widget-title text-center"><?php echo get_gameName($items[0]->gameId)->gameName;?></h4>
        </header>
    </div>
</div>
<?php } ?>
<!-- <div class="gallery row">
        <div class="promo">
        
        </div>
        </div> -->
        <?php
        if (!empty($subcategori)) { ?>
           
        <div class="col-md-12">
			<div class="panel-group accordion" id="accordion" role="tablist" aria-multiselectable="true">
				<div class="panel panel-default">
					<div class="panel-heading" role="tab" id="heading-4">
						<a class="accordion-toggle" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-4" aria-expanded="false" aria-controls="collapse-4">
							<h4 class="panel-title">Alt kategoriler</h4>
							<i class="fa acc-switch"></i>
						</a>
					</div>
					<div id="collapse-4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-4">
						<div class="panel-body">
                        <?php 
                        foreach ($subcategori as $subc) {?>
                            <a href="<?php echo base_url("blankpage/subCategoriDetail/$subc->subcategoriUrl") ?>" class="btn rounded mw-md btn-default"><h4 class="list-group-item-heading"><?php echo $subc->subcategoriName; ?></h4></a>
                        <?php
                        }
                        ?>						
                        </div>
					</div>
				</div><!-- panel-group -->
			</div><!-- END column -->
        </div>

        <?php
        }
        ?>
    <div class="container">
        <div class="col-md-12">
            <?php
        foreach ($items as $item) {
?> 
            <div class="col-md-2" style="height: 350px;">
                <div class="gallery-item">
                    <div class="thumb">
                        <a href="<?php echo base_url("uploads/games_v/$item->gameUrl/$item->imageUrl"); ?>" data-lightbox="gallery-2" data-title="<?php echo $item->imageName ?>">
                            <img style="height: 200px;" class="img-responsive" src="<?php echo base_url("uploads/games_v/$item->gameUrl/$item->imageUrl"); ?>" alt="">
                        </a>
                    </div>
                    <div class="caption text-center">
                        <h5><?php echo get_gameName($item->gameId)->gameName;?></h5>
                        <p><?php echo $item->imageName; ?></p>
                        <a download="<?php echo $item->imagePackageUrl; ?>" href="<?php echo base_url("uploads/games_v/$item->gameUrl/$item->imagePackageUrl"); ?>">
                            <button type="button" class="btn btn-info btn rounded">İndir</button>
                        </a>
                    </div>
                </div>
            </div>
<?php
        } ?>
        </div>
    </div>
<?php
    } 
?>  
</section>
