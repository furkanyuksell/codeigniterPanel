<?php 
    $user = get_active_user();
?>
<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php  echo $marketingGame->v_gameName ?> Zipleri
            <a href="<?php echo base_url("videos"); ?>" class="btn btn-outline btn-primary btn-s pull-right"> <i class="fa fa-arrow-circle-left"></i> Geri Dön</a>
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <?php if(empty($marketingZips)) { ?>

        <div class="alert alert-info text-center">
            <p>Burada herhangi bir veri bulunmamaktadır.</p>
        </div>

        <?php } else { ?>
            <div class="widget">
            <div class="widget-body">
                <div class="table-responsive">
					<table id="default-datatable" data-plugin="DataTable" class="table table-striped" cellspacing="0" width="100%">
						<thead>
							<tr>
								<th>Zip Adı</th>
								<th>İşlem</th>
							</tr>
						</thead>
						<tfoot>
							<tr>
								<th>Zip Adı</th>
								<th>İşlem</th>
							</tr>
						</tfoot>
						<tbody>

                        <?php foreach($marketingZips as $m_zip) { ?>
                            <tr>
                                <td><?php echo $m_zip->zipName; ?></td>
                                <td>
                                    <button 
                                        data-url="<?php echo base_url("videos/delete/$marketingGame->id/$marketingGame->v_gameUrl/zip_model/$m_zip->id/$m_zip->zipUrl/deleteZip") ?>" 
                                        class="btn btn-sm btn-danger btn-outline remove-btn">
                                        <i class="fa fa-trash"></i> 
                                        Sil
                                    </button>
                                </td>
                            </tr>
                        <?php } ?> 
						
                    </tbody>
					</table>
				</div>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
        <?php } ?>
    </div><!-- END column -->
</div>