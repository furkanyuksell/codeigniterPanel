<?php 
    $user = get_active_user();
?>
<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php  echo $marketingGame->v_gameName ?> Fotoğrafları
            <a href="<?php echo base_url("videos"); ?>" class="btn btn-outline btn-primary btn-s pull-right"> <i class="fa fa-arrow-circle-left"></i> Geri Dön</a>
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <?php if(empty($marketingPhotos)) { ?>

        <div class="alert alert-info text-center">
            <p>Burada herhangi bir veri bulunmamaktadır.</p>
        </div>

        <?php } else { ?>
            <div class="widget">
            <div class="widget-body">
                <div class="table-responsive">
					<table id="default-datatable" data-plugin="DataTable" class="table table-striped" cellspacing="0" width="100%">
						<thead>
							<tr>
                                <th>Görsel</th>
								<th>Oyun Adı</th>
								<th>İşlem</th>
							</tr>
						</thead>
						<tfoot>
							<tr>
                                <th>Görsel</th>
								<th>Oyun Adı</th>
								<th>İşlem</th>
							</tr>
						</tfoot>
						<tbody>
                        
                        <?php foreach($marketingPhotos as $m_photo) { ?>
                            <tr>
                                <td><img width="100px" src="<?php echo base_url("uploads/marketing_v/$marketingGame->v_gameUrl/$m_photo->photoUrl") ?>"></td> 
                                <td><?php echo $m_photo->photoName; ?></td>
                                <td>
                                    <button 
                                        data-url="<?php echo base_url("videos/delete/$marketingGame->id/$marketingGame->v_gameUrl/photo_model/$m_photo->id/$m_photo->photoUrl/deletePhoto") ?>" 
                                        class="btn btn-sm btn-danger btn-outline remove-btn">
                                        <i class="fa fa-trash"></i> 
                                        Sil
                                    </button>
                                </td>
                            </tr>
                        <?php } ?>  

						</tbody>
					</table>
				</div>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
        <?php } ?>
    </div><!-- END column -->
</div>