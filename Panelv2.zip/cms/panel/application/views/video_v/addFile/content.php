<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <b><?php echo $videoGame->v_gameName; ?></b> Tasarım Ekleme
            <a href="<?php echo base_url("videos"); ?>" class="btn btn-outline btn-primary btn-s"> <i class="fa fa-chevron-left"></i> Oyunlar</a>
        </h4>
        <p>Seçtiğiniz kategoriye yüklemelerinizi yapabilirsiniz</p>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget p-lg">
            <div class="nav-tabs-vertical clearfix">

                    <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation"><a data-toggle="tab" href="#vt-example-1" aria-controls="vt-example-1" role="tab">Video</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#vt-example-2" aria-controls="vt-example-2" role="tab">Fotoğraf</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#vt-example-3" aria-controls="vt-example-3" role="tab">Zip</a></li>
                    </ul>
                    <div class="tab-content p-h-md p-r-md">
                        <div class="tab-pane" id="vt-example-1" role="tabpanel">
                            <div class="col-md-10">
                                <form action="<?php echo base_url("videos/videoUpload/$videoGame->id/$videoGame->v_gameUrl"); ?>" class="dropzone" data-plugin="dropzone" data-options="{ url: '<?php echo base_url("videos/videoUpload/$videoGame->id/$videoGame->v_gameUrl"); ?>'}">
                                    <div class="dz-message">
                                        <h3 class="m-h-lg">Videoları buraya sürükleyin veya tıklayıp seçiniz.</h3>
                                        <p class="m-b-lg text-muted">(Videoları toplu yükleyebilirsiniz.)</p>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        <div class="tab-pane" id="vt-example-2" role="tabpanel">
                            <div class="col-md-10">
                                <form action="<?php echo base_url("videos/photoUpload/$videoGame->id/$videoGame->v_gameUrl"); ?>" class="dropzone" data-plugin="dropzone" data-options="{ url: '<?php echo base_url("videos/photoUpload/$videoGame->id/$videoGame->v_gameUrl"); ?>'}">
                                    <div class="dz-message">
                                        <h3 class="m-h-lg">Fotoğrafları buraya sürükleyin veya tıklayıp seçiniz.</h3>
                                        <p class="m-b-lg text-muted">(Fotoğrafları toplu yükleyebilirsiniz.)</p>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="tab-pane" id="vt-example-3" role="tabpanel">
                            <div class="col-md-10">
                                <form action="<?php echo base_url("videos/zipUpload/$videoGame->id/$videoGame->v_gameUrl"); ?>" class="dropzone" data-plugin="dropzone" data-options="{ url: '<?php echo base_url("videos/zipUpload/$videoGame->id/$videoGame->v_gameUrl"); ?>'}">
                                    <div class="dz-message">
                                        <h3 class="m-h-lg">Zipleri buraya sürükleyin veya tıklayıp seçiniz.</h3>
                                        <p class="m-b-lg text-muted">(Zipleri toplu yükleyebilirsiniz.)</p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    
                    </div>
                                    
			</div><!-- .nav-tabs-vertical -->

        </div><!-- .widget -->
    </div><!-- END column -->
</div>