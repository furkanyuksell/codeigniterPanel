<div class="simple-page-wrap">
    <div class="simple-page-logo animated swing">
        <a href="<?php echo base_url("login") ?>">
            <img style="width: 180px; margin-left: auto; margin-right: auto;" src="uploads/settings_v/fiber-games.png" alt="" class="img-responsive">    
        </a>
    </div><!-- logo -->
    <div class="simple-page-form animated flipInY" id="login-form">
        <h4 style="color: white;" class="form-title m-b-xl text-center">Fiber Games Paneline Giriş</h4>
        <form action="<?php echo base_url("userop/do_login"); ?>" method="post">
            <div class="form-group">
                <input id="sign-in-email" type="email" class="form-control" placeholder="E-posta" name="user_email">
                <?php if(isset($form_error)){ ?>
                    <small class="pull-right input-form-error"> <?php echo form_error("user_email"); ?></small>
                <?php } ?>
            </div>

            <div class="form-group">
                <input id="sign-in-password" type="password" class="form-control" placeholder="Şifre" name="user_password">
                <?php if(isset($form_error)){ ?>
                    <small class="pull-right input-form-error"> <?php echo form_error("user_password"); ?></small>
                <?php } ?>
            </div>

            <button type="submit" class="btn btn-primary">Giriş Yap</button>
        </form>
    </div><!-- #login-form -->

    <div class="simple-page-footer">
        <p><a style="color: #188ae2;" href="<?php echo base_url("sifremi-unuttum"); ?>"><b>Şifremi Unuttum ?</b></a></p>
    </div><!-- .simple-page-footer -->


</div><!-- .simple-page-wrap -->