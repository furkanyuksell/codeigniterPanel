<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <b><?php echo $game->gameName; ?></b> Tasarım Ekleme
            <a href="<?php echo base_url("games"); ?>" class="btn btn-outline btn-primary btn-s"> <i class="fa fa-chevron-left"></i> Oyunlar</a>
        </h4>
        <p>Seçtiğiniz kategoriye yüklemelerinizi yapabilirsiniz</p>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget p-lg">
            <div class="nav-tabs-vertical clearfix">

                    <ul class="nav nav-tabs" role="tablist">
                        <?php
                        foreach ($categori as $cat) 
                        {
                        ?>
                            <li role="presentation"><a data-toggle="tab" href="#vt-example-<?php echo $cat->id;?>" aria-controls="vt-example-<?php echo $cat->id;?>" role="tab"><?php echo $cat->categoriName ?></a></li>
                        <?php
                        }
                        ?>
                    </ul>
                    <div class="tab-content p-h-md p-r-md">
                    <?php
                    foreach ($categori as $cat) 
                    {
                    ?>
                            <div class="tab-pane" id="vt-example-<?php echo $cat->id; ?>" role="tabpanel">
                                <h4 class="m-b-md"><?php echo $cat->categoriName ?></h4>
                                <div class="col-md-10">
                                    <form action="<?php echo base_url("gallery/imageUpload/$cat->categoriName/$game->gameUrl/$game->id"); ?>" class="dropzone" data-plugin="dropzone" data-options="{ url: '<?php echo base_url("gallery/imageUpload/$cat->categoriName/$game->gameUrl/$game->id"); ?>'}">
                                        <div class="dz-message">
                                            <h3 class="m-h-lg">Dosyaları buraya sürükleyin veya tıklayıp seçiniz.</h3>
                                            <p class="m-b-lg text-muted">(Tasarım fotoğrafı ve unitypackage aynı isimde olmalı.)</p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                    <?php
                    }
                    ?>
                    </div>    
                
			</div><!-- .nav-tabs-vertical -->

        </div><!-- .widget -->
    </div><!-- END column -->
</div>