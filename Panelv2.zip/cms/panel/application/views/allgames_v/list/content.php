<?php 
    $user = get_active_user();
?>
<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Oyun Listesi
            <a href="<?php echo base_url("games/new_form"); ?>" class="btn btn-outline btn-primary btn-s pull-right"> <i class="fa fa-plus"></i> Yeni Ekle</a>
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <?php if(empty($items)) { ?>

        <div class="alert alert-info text-center">
            <p>Burada herhangi bir veri bulunmamaktadır. Eklemek için lütfen <a href="<?php echo base_url("games/new_form"); ?>">tıklayınız</a></p>
        </div>

        <?php } else { ?>
            <div class="widget">
            <div class="widget-body">
                <div class="table-responsive">
					<table id="default-datatable" data-plugin="DataTable" class="table table-striped" cellspacing="0" width="100%">
						<thead>
							<tr>
								<th>Id</th>
								<th>Oyun Adı</th>
								<th>İşlem</th>
							</tr>
						</thead>
						<tfoot>
							<tr>
                                <th>Id</th>
								<th>Oyun Adı</th>
								<th>İşlem</th>
							</tr>
						</tfoot>
						<tbody>
                        
                        <?php foreach($items as $item) { ?>

                            <tr>
                                <td>#<?php echo $item->id; ?></td>
                                <td><?php echo $item->gameName; ?></td>
                                <td>
                                    <a href="<?php echo base_url("game-detail/$item->gameUrl"); ?>" class="btn btn-sm btn-inverse btn-outline"><i class="fa fa-pencil-square-o"></i> Oyuna ait tasarımları gör</a>
                                </td>
                            </tr>

                            <?php } ?>

						</tbody>
					</table>
				</div>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
        <?php } ?>
    </div><!-- END column -->
</div>