<?php 
    $user = get_active_user();
    $categori = get_categori();  
    $games = get_games(); 
?>
<aside id="menubar" class="menubar light">
    <div class="app-user">
        <div class="media">
            <div class="media-body">
                <div class="foldable">
                    <h5><a href="javascript:void(0)" class="username"><?php echo $user->full_name; ?></a></h5>
                    <ul>
                        <li class="dropdown">
                            <a href="javascript:void(0)" class="dropdown-toggle usertitle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <small>İşlemler</small>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu animated flipInY">
                                <li>
                                    <a class="text-color" href="<?php echo base_url("users/update_form/$user->id"); ?>">
                                        <span class="m-r-xs"><i class="fa fa-user"></i></span>
                                        <span>Profil</span>
                                    </a>
                                </li>
                                <li role="separator" class="divider"></li>
                                <li>
                                    <a class="text-color" href="<?php echo base_url("logout") ?>">
                                        <span class="m-r-xs"><i class="fa fa-power-off"></i></span>
                                        <span>Çıkış</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div><!-- .media-body -->
        </div><!-- .media -->
    </div><!-- .app-user -->

    <div class="menubar-scroll">
        <div class="menubar-scroll-inner">
            <ul class="app-menu">


                <li>
                    <a href="<?php echo base_url("dashboard") ?>">
                        <i class="menu-icon fa fa-gamepad"></i>
                        <span class="menu-text">Anasayfa</span>
                    </a>
                </li>
            
                <?php foreach ($categori as $cat) {
                    if($cat->isActive){
                ?>
                    <li>
                        <a href="<?php echo base_url("category-detail/$cat->categoriUrl"); ?>">
                            <i class="menu-icon <?php echo $cat->categoriIcon; ?>"></i>
                            <span class="menu-text"><?php echo $cat->categoriName; ?></span>
                        </a>
                    </li>
                <?php 
                    }
                } 
                ?>
                <li>
                    <a href="<?php echo base_url("allgames") ?>">
                        <i class="menu-icon fa fa-gamepad"></i>
                        <span class="menu-text">Oyunlar</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url("allcreatives") ?>">
                        <i class="menu-icon fa fa-youtube"></i>
                        <span class="menu-text">Creative Notes</span>
                    </a>
                </li>
                <li class="has-submenu">
                    <a href="javascript:void(0)" class="submenu-toggle">
                        <i class="menu-icon zmdi zmdi-view-dashboard zmdi-hc-lg"></i>
                        <span class="menu-text">Aktif Oyunlar</span>
                        <i class="menu-caret zmdi zmdi-hc-sm zmdi-chevron-right"></i>
                    </a>
                    <ul class="submenu">
                        <?php 
                        $i = 0;
                        foreach ($games as $game) { if($i < 5){?>
                          
                          <li><a href="<?php echo base_url("game-detail/$game->gameUrl"); ?>"><span class="menu-text"><?php echo $game->gameName; ?></span></a></li>

                        <?php
                        }$i++;}
                        ?>
                    </ul>
                </li>

                <li class="menu-separator"><hr></li>
                <?php 
                if ($user->userLevel == 1) { ?>
                <li>
                    <a href="<?php echo base_url("categori"); ?>">
                        <i class="menu-icon fa fa-list"></i>
                        <span class="menu-text">Kategori Oluştur</span>
                    </a>
                </li>
                <?php } ?>
                
                <li>
                    <a href="<?php echo base_url("subcategori"); ?>">
                        <i class="menu-icon fa fa-list-alt"></i>
                        <span class="menu-text">Alt Kategori Oluştur</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url("games"); ?>">
                        <i class="menu-icon fa fa-image"></i>
                        <span class="menu-text">Tasarım Ekle</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url("videos"); ?>">
                        <i class="menu-icon fa fa-play"></i>
                        <span class="menu-text">Marketing</span>
                    </a>
                </li>
                <?php 
                if ($user->userLevel == 1) { ?>
                <li>
                    <a href="<?php echo base_url("users"); ?>">
                        <i class="menu-icon fa fa-user"></i>
                        <span class="menu-text">Kullanıcılar</span>
                    </a>
                </li>        
                

                <li>
                    <a href="<?php echo base_url("settings") ?>">
                        <i class="menu-icon zmdi zmdi-settings zmdi-hc-lg"></i>
                        <span class="menu-text">Ayarlar</span>
                    </a>
                </li>       
                <?php } ?>
            </ul><!-- .app-menu -->
        </div><!-- .menubar-scroll-inner -->
    </div><!-- .menubar-scroll -->
</aside>