<!DOCTYPE html>
<html lang="tr">
<head>
    <?php $this->load->view("includes/head"); ?>
    <?php $this->load->view("error_v/page_style"); ?>
</head>

<body style="background-color: black;" class="simple-page">
<!--============= start main area -->

    <!-- APP MAIN ==========-->
        <?php $this->load->view("error_v/content"); ?>
    <!--========== END app main -->


</body>
</html>