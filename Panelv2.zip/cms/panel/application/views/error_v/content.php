<div id="back-to-home">
		<a href="<?php echo base_url("dashboard") ?>" class="btn btn-outline btn-default"><i class="fa fa-home animated zoomIn"></i></a>
	</div>
	<div class="simple-page-wrap">
		<div class="simple-page-logo animated swing">
			<a href="<?php echo base_url("dashboard") ?>">
                <img style="margin-left: auto; margin-right: auto;" src="<?php echo base_url("uploads/settings_v/logo-fibergames.png"); ?>" alt="" class="img-responsive">    
			</a>
		</div><!-- logo -->
		<h1 id="_404_title" class="animated shake">404</h1>
	<h5 id="_404_msg" class="animated slideInUp">Aradığınız sayfa bulunamadı <br><br> Anasayfaya dönmek için <a href="<?php echo base_url("dashboard") ?>">tıklayınız</a></h5>

</div><!-- .simple-page-wrap -->