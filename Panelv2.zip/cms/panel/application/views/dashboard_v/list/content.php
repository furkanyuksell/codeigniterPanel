<?php 

if (empty($item)) {
    echo "Henüz bir dokümantasyon girilmemiş. Girmek için"; 
    ?>
    <a href="<?php echo base_url("settings") ?>">tıklayınız.</a>
<?php
}else{
    echo $item->document;
}

?>